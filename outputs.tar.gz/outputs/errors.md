+ HPL : `[host2:46:(47) 389180665.481103] ./src/xbt/xbt_replay.cpp:106: [root/CRITICAL] Replay Error: action sendRecv is unknown, please register it properly in the replay engine`
+ PTRANS: `[165132947.000000] ./src/kernel/EngineImpl.cpp:748: [ker_engine/CRITICAL] Oops! Deadlock or code not perfectly clean.`
